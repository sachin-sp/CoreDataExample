//
//  ViewController.swift
//  AttributedText
//
//  Created by Sachin Pampannavar on 14/10/22.
//

import UIKit

class ViewController: UIViewController {

    lazy var logTextView: UITextView = {
       let tv = UITextView()
        tv.font = UIFont.systemFont(ofSize: 14)
        tv.translatesAutoresizingMaskIntoConstraints = false
        tv.isEditable = false
        tv.isSelectable = true
        tv.textAlignment = .left
       return tv
    }()
    
    var attributtedLogText = NSMutableAttributedString()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        logTextView.backgroundColor = .clear
        LogManager.shared.delegate = self
        setupUI()
        LogManager.shared.add(log: Log(text: "1", detailLogs: [Log(text: "1-1", detailLogs: [], color: .systemBlue),
                                                               Log(text: "1-2", detailLogs: [], color: .systemBlue),
                                                               Log(text: "1-3", detailLogs: [Log(text: "1-3-1", detailLogs: [], color: .systemBlue),
                                                                                             Log(text: "1-3-2", detailLogs: [], color: .systemBlue),
                                                                                             Log(text: "1-3-3", detailLogs: [Log(text: "1-3-3-1", detailLogs: [], color: .systemBlue)], color: .systemBlue)], color: .systemBlue),
                                                               Log(text: "1-4", detailLogs: [], color: .systemBlue),
                                                               Log(text: "1-5", detailLogs: [], color: .systemBlue)], color: .systemGreen))
    }
    private func setupUI() {
        view.addSubview(logTextView)
        let safeAreaLayoutGuide = view.safeAreaLayoutGuide
        logTextView.topAnchor.constraint(equalTo: safeAreaLayoutGuide.topAnchor, constant: 8).isActive = true
        logTextView.leftAnchor.constraint(equalTo: safeAreaLayoutGuide.leftAnchor, constant: 8).isActive = true
        logTextView.rightAnchor.constraint(equalTo: safeAreaLayoutGuide.rightAnchor, constant: -8).isActive = true
        logTextView.bottomAnchor.constraint(equalTo: safeAreaLayoutGuide.bottomAnchor, constant: -8).isActive = true
    }

}
extension ViewController: LogDelegate {
    func didAddLog() {
        logTextView.attributedText = LogManager.shared.attributtedLogText
    }
}

protocol LogDelegate {
    
    func didAddLog()
    
}

class LogManager {
    
    static let shared = LogManager()
    
    private(set) var attributtedLogText = NSMutableAttributedString()
    
    var delegate: LogDelegate?
        
    private init() {}
    
    func clearLog() {
        self.attributtedLogText = NSMutableAttributedString()
        delegate?.didAddLog()
    }

    func add(log: Log, space: String = "") {
        var space = space
        space.append(" ")
        
        let logTextAttributes: [NSAttributedString.Key: Any] = [
            .font: log.font,
            .foregroundColor: log.color,
        ]
        
        let attributedText = NSMutableAttributedString(string: "\(log.text)\n", attributes: logTextAttributes)
        self.attributtedLogText.append(attributedText)
        
        for detailLog in log.detailLogs {
            let spaceAttributes: [NSAttributedString.Key: Any] = [
                .font: detailLog.font,
                .foregroundColor: detailLog.color,
            ]
            let spaceAttributedText = NSMutableAttributedString(string: space, attributes: spaceAttributes)
            self.attributtedLogText.append(spaceAttributedText)
            add(log: detailLog, space: space)
        }
        delegate?.didAddLog()
    }
    
}

struct Log {
    
    var text = ""
    var detailLogs = [Log]()
    var color = UIColor.systemGreen
    var font = UIFont.monospacedSystemFont(ofSize: 14, weight: .regular)
}
