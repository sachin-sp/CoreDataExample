//
//  CDPropertyEntity.swift
//  CoreDataExample
//
//  Created by Sachin Pampannavar on 26/12/22.
//

import Foundation

class CDPropertyEntity: BaseEntity { }

extension CDPropertyEntity: CoreDataOperations {
    func insertOrUpdate(records: [Properties]) {
        DispatchQueue.global(qos: .background).async {
            self.privateMOC.performAndWait {
                records.forEach { property in
                    let modelID = property.modelID ?? ""
                    let existingCDProperty = self.getCDProperty(by: modelID)
                    if existingCDProperty == nil {
                        self.insert(property: property)
                    } else {
                        self.update(property: property)
                    }
                }
                self.synchronize()
            }
        }
    }
    
    func delete(records: [Properties]) {
        DispatchQueue.global(qos: .background).async {
            self.privateMOC.performAndWait {
                records.forEach { property in
                    if let cdProperty = self.getCDProperty(by: property.modelID ?? "") {
                        self.privateMOC.delete(cdProperty)
                    }
                }
                self.synchronize()
            }
        }
    }
    
    func fetchAll(completion: @escaping (([Properties]?) -> Void)) {
        DispatchQueue.global(qos: .background).async {
            self.privateMOC.performAndWait {
                let fetchReq = CDProperty.fetchRequest()
                let records = try? self.privateMOC.fetch(fetchReq)
                let properties = records?.toProperties()
                completion(properties)
            }
        }
    }
    
    typealias T = Properties
    
    
}

extension CDPropertyEntity {
    private func insert(property: Properties) {
        let newCDProperty = CDProperty(context: self.privateMOC)
        newCDProperty.modelID = property.modelID
        newCDProperty.connected = property.connected
        newCDProperty.timeZone = property.timeZone
    }
    private func update(property: Properties) {
        let existingCDProperty = getCDProperty(by: property.modelID ?? "")
        existingCDProperty?.modelID = property.modelID
        existingCDProperty?.connected = property.connected
        existingCDProperty?.timeZone = property.timeZone
    }
    private func getCDProperty(by id: String) -> CDProperty? {
        var cdProperty: CDProperty?
        self.privateMOC.performAndWait {
            let fetchReq = CDProperty.fetchRequest()
            fetchReq.predicate = NSPredicate(format: "modelID == %@", id)
            let records = try? privateMOC.fetch(fetchReq)
            cdProperty = records?.first
        }
        return cdProperty
    }
}
