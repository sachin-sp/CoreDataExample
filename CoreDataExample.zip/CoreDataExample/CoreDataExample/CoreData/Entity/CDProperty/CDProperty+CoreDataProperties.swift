//
//  CDProperty+CoreDataProperties.swift
//  CoreDataExample
//
//  Created by Sachin Pampannavar on 26/12/22.
//
//

import Foundation
import CoreData


extension CDProperty {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<CDProperty> {
        return NSFetchRequest<CDProperty>(entityName: "CDProperty")
    }

    @NSManaged public var connected: String?
    @NSManaged public var modelID: String?
    @NSManaged public var timeZone: String?

}

extension CDProperty : Identifiable {

}

extension CDProperty {
    func toProperties() -> Properties? {
        return Properties(modelID: modelID, timeZone: timeZone, connected: connected)
    }
}

extension Array where Element: CDProperty {
    func toProperties() -> [Properties]? {
        var properties = [Properties]()
        self.forEach { cdProperty in
            if let property = cdProperty.toProperties() {
                properties.append(property)
            }
        }
        return properties
    }
}
