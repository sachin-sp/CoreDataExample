//
//  CDProperty+CoreDataClass.swift
//  CoreDataExample
//
//  Created by Sachin Pampannavar on 26/12/22.
//
//

import Foundation
import CoreData

@objc(CDProperty)
public class CDProperty: NSManagedObject {

    enum key: String {
        case connected
        case modelID
        case timeZone
    }
}

// MARK: - Properties
struct Properties: Codable, Hashable {
    var modelID, timeZone, connected: String?

    enum CodingKeys: String, CodingKey {
        case modelID = "modelId"
        case timeZone
        case connected
    }
}
