//
//  CDUserEntity.swift
//  CoreDataExample
//
//  Created by Sachin Pampannavar on 26/12/22.
//

import Foundation

class CDUserEntity: BaseEntity { }

extension CDUserEntity: CoreDataOperations {
    func insertOrUpdate(records: [Users]) {
        DispatchQueue.global(qos: .background).async {
            self.privateMOC.performAndWait {
                records.forEach { user in
                    let id = user.accountID ?? ""
                    let existingCDUser = self.getCDUser(by: id)
                    if existingCDUser == nil {
                        self.insert(user: user)
                    } else {
                        self.update(user: user)
                    }
                }
                self.synchronize()
            }
        }
    }
    
    func delete(records: [Users]) {
        DispatchQueue.global(qos: .background).async {
            self.privateMOC.performAndWait {
                records.forEach { user in
                    if let cdUser = self.getCDUser(by: user.accountID ?? "") {
                        self.privateMOC.delete(cdUser)
                    }
                }
                self.synchronize()
            }
        }
    }
    
    func fetchAll(completion: @escaping (([Users]?) -> Void)) {
        DispatchQueue.global(qos: .background).async {
            self.privateMOC.performAndWait {
                let fetchReq = CDUser.fetchRequest()
                let records = try? self.privateMOC.fetch(fetchReq)
                let users = records?.toUsersArray()
                completion(users)
            }
        }
    }
    
    typealias T = Users
    
}

extension CDUserEntity {
    private func insert(user: Users) {
        let cdUser = CDUser(context: self.privateMOC)
        cdUser.firstName = user.firstName
        cdUser.lastName = user.lastName
        cdUser.name = user.name
        cdUser.email = user.email
        cdUser.role = user.role
        cdUser.phone = user.phoneNumber
        cdUser.accountStatus = user.accountStatus
        cdUser.disabledDate = Int64(user.disabledDate ?? 0)
        cdUser.accountId = user.accountID
        cdUser.activeDate = Int64(user.activeDate ?? 0)
        cdUser.createdDate = Int64(user.createdDate ?? 0)
        cdUser.updatedDate = Int64(user.updatedDate ?? 0)
        cdUser.orgID = user.orgID
    }
    private func update(user: Users) {
        let existingCDuser = getCDUser(by: user.accountID ?? "")
        existingCDuser?.firstName = user.firstName
        existingCDuser?.lastName = user.lastName
        existingCDuser?.name = user.name
        existingCDuser?.email = user.email
        existingCDuser?.role = user.role
        existingCDuser?.phone = user.phoneNumber
        existingCDuser?.accountStatus = user.accountStatus
        existingCDuser?.disabledDate = Int64(user.disabledDate ?? 0)
        existingCDuser?.accountId = user.accountID
        existingCDuser?.activeDate = Int64(user.activeDate ?? 0)
        existingCDuser?.createdDate = Int64(user.createdDate ?? 0)
        existingCDuser?.updatedDate = Int64(user.updatedDate ?? 0)
        existingCDuser?.orgID = user.orgID
    }
    private func getCDUser(by id: String) -> CDUser? {
        var cdUser: CDUser?
        self.privateMOC.performAndWait {
            let fetchReq = CDUser.fetchRequest()
            fetchReq.predicate = NSPredicate(format: "accountId == %@", id)
            let records = try? privateMOC.fetch(fetchReq)
            cdUser = records?.first
        }
        return cdUser
    }
}
