//
//  CDUser+CoreDataClass.swift
//  CoreDataExample
//
//  Created by Sachin Pampannavar on 26/12/22.
//
//

import Foundation
import CoreData

@objc(CDUser)
public class CDUser: NSManagedObject {

    enum key: String {
        case accountId
        case accountStatus
        case activeDate
        case createdDate
        case disabledDate
        case email
        case firstName
        case lastName
        case name
        case orgID
        case phone
        case role
        case updatedDate
    }
}

struct Users: Codable {
    let firstName, lastName, name, email: String?
    let activeDate: Int?
    var role, accountStatus, phoneNumber: String?
    let disabledDate, createdDate, updatedDate: Int?
    let accountID: String?
    var orgID: String?

    enum CodingKeys: String, CodingKey {
        case firstName, lastName, name, email, activeDate, role, accountStatus, phoneNumber, disabledDate, createdDate, updatedDate
        case accountID = "accountId"
        case orgID
    }
}
