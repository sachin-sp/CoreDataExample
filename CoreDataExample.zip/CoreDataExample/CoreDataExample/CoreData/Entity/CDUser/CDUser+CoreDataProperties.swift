//
//  CDUser+CoreDataProperties.swift
//  CoreDataExample
//
//  Created by Sachin Pampannavar on 26/12/22.
//
//

import Foundation
import CoreData


extension CDUser {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<CDUser> {
        return NSFetchRequest<CDUser>(entityName: "CDUser")
    }

    @NSManaged public var accountId: String?
    @NSManaged public var accountStatus: String?
    @NSManaged public var activeDate: Int64
    @NSManaged public var createdDate: Int64
    @NSManaged public var disabledDate: Int64
    @NSManaged public var email: String?
    @NSManaged public var firstName: String?
    @NSManaged public var lastName: String?
    @NSManaged public var name: String?
    @NSManaged public var orgID: String?
    @NSManaged public var phone: String?
    @NSManaged public var role: String?
    @NSManaged public var updatedDate: Int64

}

extension CDUser : Identifiable {

}

extension CDUser {
    func toUsers() -> Users? {
        return Users(firstName: firstName, lastName: lastName, name: name, email: email, activeDate: Int(activeDate), disabledDate: Int(disabledDate), createdDate: Int(createdDate), updatedDate: Int(updatedDate), accountID: accountId)
    }
}

extension Array where Element: CDUser {
    func toUsersArray() -> [Users]? {
        var users = [Users]()
        self.forEach { cdAccount in
            if let user = cdAccount.toUsers() {
                users.append(user)
            }
        }
        return users
    }
}
