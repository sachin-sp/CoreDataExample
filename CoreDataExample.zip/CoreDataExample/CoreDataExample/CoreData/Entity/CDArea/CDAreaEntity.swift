//
//  CDAreaEntity.swift
//  CoreDataExample
//
//  Created by Sachin Pampannavar on 24/12/22.
//

import Foundation
import CoreData

class CDAreaEntity: BaseEntity { }

extension CDAreaEntity: CoreDataOperations {
    func insertOrUpdate(records: [Area]) {
        DispatchQueue.global(qos: .background).async {
            self.privateMOC.performAndWait {
                self.syncLocalDataWithRemote(records: records)
                records.forEach { area in
                    let id = area.areaID ?? ""
                    let existingCDArea = self.getCDArea(by: id)
                    if existingCDArea == nil {
                        self.insert(area: area)
                    } else {
                        self.update(area: area)
                    }
                }
                self.synchronize()
            }
        }
    }
    
    func fetchAll(completion: @escaping (([Area]?) -> Void)) {
                
        DispatchQueue.global(qos: .background).async {
            self.privateMOC.performAndWait {
                let fetchReq = CDArea.fetchRequest()
                let records = try? self.privateMOC.fetch(fetchReq)
                let areas = records?.toAreas()
                completion(areas)
            }
        }
    }
    
    func delete(records: [Area]) {
        DispatchQueue.global(qos: .background).async {
            self.privateMOC.performAndWait {
                records.forEach { area in
                    if let cdArea = self.getCDArea(by: area.areaID ?? "") {
                        self.privateMOC.delete(cdArea)
                    }
                }
                self.synchronize()
            }
        }
    }
        
    typealias T = Area
    
    
}

extension CDAreaEntity {
    
    private func syncLocalDataWithRemote(records: [Area]) {
        let locationIDs = records.map { area in area.locationID ?? "" }
        let uniqueLocationIDs = Array(Set(locationIDs))
        uniqueLocationIDs.forEach { locationID in
            self.fetchAll { areas in
                if let areas = areas {
                    let localAreaIDs = areas.filter({ area in
                        area.locationID == locationID
                    }).map({ area in
                        area.areaID ?? ""
                    })
                    let remoteAreaIDs = records.filter { area in
                        return area.locationID == locationID
                    }.map { area in
                        area.areaID ?? ""
                    }
                    let localAreaIDsToDelete = self.localIDsToDelete(localIDs: localAreaIDs, remoteIDs: remoteAreaIDs)
                    self.delete(areaIDs: localAreaIDsToDelete)
                }
                
            }
        }
    }
    
    private func localIDsToDelete(localIDs: [String], remoteIDs: [String]) -> [String] {
        var ids = [String]()
        localIDs.forEach { localID in
            if !remoteIDs.contains(localID) {
                ids.append(localID)
            }
        }
        return ids
    }
    
    func delete(areaIDs: [String]) {
        self.privateMOC.performAndWait {
            areaIDs.forEach { areaID in
                let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "CDArea")
                let fetchById = NSPredicate(format: "areaID==%@", areaID as CVarArg)
                fetchRequest.predicate = fetchById
                let batchDeleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)
                do {
                    try self.privateMOC.execute(batchDeleteRequest)
                }
                catch let error as NSError {
                    print(error.localizedDescription)
                }
            }
        }
    }
    
}

extension CDAreaEntity {
    
    private func insert(area: Area) {
        let newCDArea = CDArea(context: self.privateMOC)
        newCDArea.orgID = area.orgID
        newCDArea.locationID = area.locationID
        newCDArea.areaID = area.areaID
        newCDArea.areaName = area.areaName
        newCDArea.isDefault = area.isDefault ?? false
        newCDArea.createdDate = Int64(area.createdDate ?? 0)
    }
    
    private func update(area: Area) {
        let areaID = area.areaID ?? ""
        let existingCDArea = getCDArea(by: areaID)
        existingCDArea?.orgID = area.orgID
        existingCDArea?.locationID = area.locationID
        existingCDArea?.areaID = area.areaID
        existingCDArea?.areaName = area.areaName
        existingCDArea?.isDefault = area.isDefault ?? false
        existingCDArea?.createdDate = Int64(area.createdDate ?? 0)
    }
    
    func getCDArea(by id: String) -> CDArea? {
        var cdArea: CDArea?
        self.privateMOC.performAndWait {
            let fetchReq = CDArea.fetchRequest()
            fetchReq.predicate = NSPredicate(format: "areaID == %@", id)
            let records = try? privateMOC.fetch(fetchReq)
            cdArea = records?.first
        }
        return cdArea
    }
}

