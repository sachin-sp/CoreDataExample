//
//  CDArea+CoreDataClass.swift
//  CoreDataExample
//
//  Created by Sachin Pampannavar on 24/12/22.
//
//

import Foundation
import CoreData

@objc(CDArea)
public class CDArea: NSManagedObject {
    
    enum key: String {
        case activeDate
        case areaID
        case areaName
        case areaStatus
        case createdDate
        case isDefault
        case locationID
        case orgID
        
        case cdLocation
    }
   
}

// MARK: - Area
struct Area: Codable, Hashable {
    
    let orgID, locationID, areaID: String?
    let areaName: String?
    let isDefault: Bool?
    let createdDate: Int?
    
    enum CodingKeys: String, CodingKey {
        case orgID = "orgId"
        case locationID = "locationId"
        case areaID = "areaId"
        case areaName, isDefault, createdDate
    }
}
