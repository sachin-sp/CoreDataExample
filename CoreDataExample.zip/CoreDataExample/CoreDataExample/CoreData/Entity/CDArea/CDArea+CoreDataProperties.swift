//
//  CDArea+CoreDataProperties.swift
//  CoreDataExample
//
//  Created by Sachin Pampannavar on 24/12/22.
//
//

import Foundation
import CoreData


extension CDArea {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<CDArea> {
        return NSFetchRequest<CDArea>(entityName: "CDArea")
    }

    @NSManaged public var activeDate: Int64
    @NSManaged public var areaID: String?
    @NSManaged public var areaName: String?
    @NSManaged public var areaStatus: String?
    @NSManaged public var createdDate: Int64
    @NSManaged public var isDefault: Bool
    @NSManaged public var locationID: String?
    @NSManaged public var orgID: String?
    
    @NSManaged public var cdLocation: CDLocation?

}

extension CDArea : Identifiable {

    func toArea() -> Area? {
        return Area(orgID: orgID, locationID: locationID, areaID: areaID, areaName: areaName, isDefault: isDefault, createdDate: Int(createdDate))
    }
}

extension Array where Element: CDArea {
    func toAreas() -> [Area]? {
        var areas = [Area]()
        self.forEach { cdArea in
            if let area = cdArea.toArea() {
                areas.append(area)
            }
        }
        return areas
    }
}
