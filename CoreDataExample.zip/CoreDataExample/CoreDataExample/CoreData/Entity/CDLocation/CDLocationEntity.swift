//
//  CDLocationEntity.swift
//  CoreDataExample
//
//  Created by Sachin Pampannavar on 24/12/22.
//

import Foundation
import CoreData

class CDLocationEntity: BaseEntity { }

extension CDLocationEntity: CoreDataOperations {
    
    func insertOrUpdate(records: [Location]) {
        DispatchQueue.global(qos: .background).async {
            self.privateMOC.performAndWait {
                self.syncLocalDataWithRemote(records: records)
                records.forEach { location in
                    let id = location.locationID ?? ""
                    let existingCDLocation = self.getCDLocation(by: id)
                    if existingCDLocation == nil {
                        self.insert(location: location)
                    } else {
                        self.update(location: location)
                    }
                }
                self.synchronize()
            }
        }
    }
    
    func fetchAll(completion: @escaping (([Location]?) -> Void)) {
        DispatchQueue.global(qos: .background).async {
            self.privateMOC.performAndWait {
                let fetchReq = CDLocation.fetchRequest()
                let records = try? self.privateMOC.fetch(fetchReq)
                let locations = records?.toLocations()
                completion(locations)
            }
        }
    }
    
    func delete(records: [Location]) {
        DispatchQueue.global(qos: .background).async {
            self.privateMOC.performAndWait {
                records.forEach { location in
                    if let cdLocaiton = self.getCDLocation(by: location.locationID ?? "") {
                        self.privateMOC.delete(cdLocaiton)
                    }
                }
                self.synchronize()
            }
        }
    }
    
    typealias T = Location
    
    
}

extension CDLocationEntity {
    
    private func syncLocalDataWithRemote(records: [Location]) {
        let orgIDs = records.map { location in location.orgID ?? "" }
        let uniqueOrgIDs = Array(Set(orgIDs))
        uniqueOrgIDs.forEach { orgID in
            self.fetchAll { locations in
                if let locations = locations {
                    let localLocationIDs = locations.filter { location in
                        location.orgID == orgID
                    }.map { location in
                        location.locationID ?? ""
                    }
                    let remoteLocationIDS = records.filter { location in
                        return location.orgID == orgID
                    }.map { location in
                        location.locationID ?? ""
                    }
                    let localLocationIDsToDelete = self.localIDsToDelete(localIDs: localLocationIDs, remoteIDs: remoteLocationIDS)
                    self.delete(locationIDs: localLocationIDsToDelete)
                }
            }
        }
    }
    
    private func localIDsToDelete(localIDs: [String], remoteIDs: [String]) -> [String] {
        var ids = [String]()
        localIDs.forEach { localID in
            if !remoteIDs.contains(localID) {
                ids.append(localID)
            }
        }
        return ids
    }
    
    func delete(locationIDs: [String]) {
        self.privateMOC.performAndWait {
            locationIDs.forEach { locationID in
                let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "CDLocation")
                let fetchById = NSPredicate(format: "locationID==%@", locationID as CVarArg)
                fetchRequest.predicate = fetchById
                let batchDeleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)
                do {
                    try self.privateMOC.execute(batchDeleteRequest)
                }
                catch let error as NSError {
                    print(error.localizedDescription)
                }
            }
            synchronize()
        }
    }
    
}

extension CDLocationEntity {
    
    private func insert(location: Location) {
        let newCDlocation = CDLocation(context: self.privateMOC)
        newCDlocation.orgID = location.orgID
        newCDlocation.locationID = location.locationID
        newCDlocation.locationName = location.locationName
        newCDlocation.addressLine1 = location.addressLine1
        newCDlocation.addressLine2 = location.addressLine2
        newCDlocation.city = location.city
        newCDlocation.state = location.state
        newCDlocation.zipcode = location.zipcode
        newCDlocation.isDefault = location.isDefault
        newCDlocation.country = location.country
        newCDlocation.lat = location.lat ?? 0.0
        newCDlocation.lng = location.lng ?? 0.0
        newCDlocation.createdDate = Int64(location.createdDate)
        newCDlocation.updatedDate = Int64(location.updatedDate ?? 0)
        let areas = location.areas ?? []
        areas.forEach { area in
            insertOrUpdateArea(area: area, cdLocation: newCDlocation)
        }
    }
    
    private func update(location: Location) {
        let existingLocation = getCDLocation(by: location.locationID ?? "")
        existingLocation?.orgID = location.orgID
        existingLocation?.locationID = location.locationID
        existingLocation?.locationName = location.locationName
        existingLocation?.addressLine1 = location.addressLine1
        existingLocation?.addressLine2 = location.addressLine2
        existingLocation?.city = location.city
        existingLocation?.state = location.state
        existingLocation?.zipcode = location.zipcode
        existingLocation?.isDefault = location.isDefault
        existingLocation?.country = location.country
        existingLocation?.lat = location.lat ?? 0.0
        existingLocation?.lng = location.lng ?? 0.0
        existingLocation?.createdDate = Int64(location.createdDate)
        existingLocation?.updatedDate = Int64(location.updatedDate ?? 0)
        let areas = location.areas ?? []
        areas.forEach { area in
            insertOrUpdateArea(area: area, cdLocation: existingLocation)
        }
    }
    
    private func insertOrUpdateArea(area: Area, cdLocation: CDLocation?) {
        let areaID = area.areaID ?? ""
        let existingCDArea = getCDArea(by: areaID)
        if existingCDArea == nil {
            let newCDArea = CDArea(context: self.privateMOC)
            newCDArea.orgID = area.orgID
            newCDArea.locationID = area.locationID
            newCDArea.areaID = area.areaID
            newCDArea.areaName = area.areaName
            newCDArea.isDefault = area.isDefault ?? false
            newCDArea.createdDate = Int64(area.createdDate ?? 0)
            cdLocation?.addToCdAreas(newCDArea)
        } else {
            existingCDArea?.orgID = area.orgID
            existingCDArea?.locationID = area.locationID
            existingCDArea?.areaID = area.areaID
            existingCDArea?.areaName = area.areaName
            existingCDArea?.isDefault = area.isDefault ?? false
            existingCDArea?.createdDate = Int64(area.createdDate ?? 0)
        }
    }
    
    private func getCDLocation(by id: String) -> CDLocation? {
        var cdLocation: CDLocation?
        self.privateMOC.performAndWait {
            let fetchReq = CDLocation.fetchRequest()
            fetchReq.predicate = NSPredicate(format: "locationID == %@", id)
            let records = try? privateMOC.fetch(fetchReq)
            cdLocation = records?.first
        }
        return cdLocation
    }
    
    private func getCDArea(by id: String) -> CDArea? {
        var cdArea: CDArea?
        self.privateMOC.performAndWait {
            let fetchReq = CDArea.fetchRequest()
            fetchReq.predicate = NSPredicate(format: "areaID == %@", id)
            let records = try? privateMOC.fetch(fetchReq)
            cdArea = records?.first
        }
        return cdArea
    }
}
