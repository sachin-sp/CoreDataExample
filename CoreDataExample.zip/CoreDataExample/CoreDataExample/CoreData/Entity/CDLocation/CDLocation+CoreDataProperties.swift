//
//  CDLocation+CoreDataProperties.swift
//  CoreDataExample
//
//  Created by Sachin Pampannavar on 24/12/22.
//
//

import Foundation
import CoreData


extension CDLocation {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<CDLocation> {
        return NSFetchRequest<CDLocation>(entityName: "CDLocation")
    }

    @NSManaged public var activeDate: Int64
    @NSManaged public var addressLine1: String?
    @NSManaged public var addressLine2: String?
    @NSManaged public var city: String?
    @NSManaged public var country: String?
    @NSManaged public var createdDate: Int64
    @NSManaged public var isDefault: String?
    @NSManaged public var lat: Double
    @NSManaged public var lng: Double
    @NSManaged public var locationID: String?
    @NSManaged public var locationName: String?
    @NSManaged public var orgID: String?
    @NSManaged public var state: String?
    @NSManaged public var updatedDate: Int64
    @NSManaged public var zipcode: String?
    
    @NSManaged public var cdAreas: NSSet?
    @NSManaged public var cdOrganisation: CDOrganisation?

}

// MARK: Generated accessors for cdAreas
extension CDLocation {

    @objc(addCdAreasObject:)
    @NSManaged public func addToCdAreas(_ value: CDArea)

    @objc(removeCdAreasObject:)
    @NSManaged public func removeFromCdAreas(_ value: CDArea)

    @objc(addCdAreas:)
    @NSManaged public func addToCdAreas(_ values: NSSet)

    @objc(removeCdAreas:)
    @NSManaged public func removeFromCdAreas(_ values: NSSet)

}

extension CDLocation : Identifiable {

}

extension CDLocation {
    func toLocation() -> Location? {
        var areas = [Area]()
        if let cdAreas = self.cdAreas?.allObjects as? [CDArea]{
            cdAreas.forEach({ cdArea in
                if let area = cdArea.toArea() {
                    areas.append(area)

                }
            })
        }
        return Location(orgID: orgID, locationID: locationID, locationName: locationName, addressLine1: addressLine1, addressLine2: addressLine2, city: city, state: state, country: country, zipcode: zipcode, createdDate: Int(createdDate), updatedDate: Int(updatedDate), isDefault: isDefault, lat: lat, lng: lng)
    }
}

extension Array where Element: CDLocation {
    func toLocations() -> [Location]? {
        var locations = [Location]()
        self.forEach { cdLocation in
            if let location = cdLocation.toLocation() {
                locations.append(location)
            }
        }
        return locations
    }
}
