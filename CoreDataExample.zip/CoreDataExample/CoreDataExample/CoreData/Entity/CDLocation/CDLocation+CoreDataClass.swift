//
//  CDLocation+CoreDataClass.swift
//  CoreDataExample
//
//  Created by Sachin Pampannavar on 24/12/22.
//
//

import Foundation
import CoreData

@objc(CDLocation)
public class CDLocation: NSManagedObject {
    enum key: String {
        case activeDate
        case addressLine1
        case addressLine2
        case city
        case country
        case createdDate
        case isDefault
        case lat
        case lng
        case locationID
        case locationName
        case orgID
        case state
        case updatedDate
        case zipcode
        
        case cdAreas
        case cdOrganisation
    }
}

struct Location: Codable, Hashable {
    
    let orgID, locationID, locationName, addressLine1: String?
    let addressLine2: String?
    let city, state: String?
    let country: String?
    let zipcode: String?
    let createdDate: Int
    let updatedDate: Int?
    let isDefault: String?
    let lat, lng: Double?
    var areas: [Area]?
    
    enum CodingKeys: String, CodingKey {
        case orgID = "orgId"
        case locationID = "locationId"
        case locationName, addressLine1, addressLine2, city, state, country, zipcode, createdDate, updatedDate, isDefault, lat, lng, areas
    }
}
