//
//  CDAccount+CoreDataProperties.swift
//  CoreDataExample
//
//  Created by Sachin Pampannavar on 26/12/22.
//
//

import Foundation
import CoreData


extension CDAccount {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<CDAccount> {
        return NSFetchRequest<CDAccount>(entityName: "CDAccount")
    }

    @NSManaged public var accountID: String?
    @NSManaged public var accountStatus: String?
    @NSManaged public var activeDate: Int64
    @NSManaged public var createdDate: Int64
    @NSManaged public var disableDate: Int64
    @NSManaged public var email: String?
    @NSManaged public var firstName: String?
    @NSManaged public var lastName: String?
    @NSManaged public var paymentID: String?
    @NSManaged public var updatedDate: Int64

}

extension CDAccount : Identifiable {

}

extension CDAccount {
    func toCustomerAccount() -> CustomerAccount? {
        return CustomerAccount(accountID: accountID, firstName: firstName, lastName: lastName, email: email, activeDate: Int(activeDate), disableDate: Int(disableDate), accountStatus: accountStatus, createdDate: Int(createdDate), updatedDate: Int(updatedDate), paymentID: paymentID)
    }
}

extension Array where Element: CDAccount {
    func toCustomerAccounts() -> [CustomerAccount]? {
        var accounts = [CustomerAccount]()
        self.forEach { cdAccount in
            if let account = cdAccount.toCustomerAccount() {
                accounts.append(account)
            }
        }
        return accounts
    }
}
