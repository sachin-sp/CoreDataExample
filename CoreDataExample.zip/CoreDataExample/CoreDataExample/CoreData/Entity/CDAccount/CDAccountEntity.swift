//
//  CDAccountEntity.swift
//  CoreDataExample
//
//  Created by Sachin Pampannavar on 26/12/22.
//

import Foundation

class CDAccountEntity: BaseEntity { }

extension CDAccountEntity {
    func insertOrUpdate(records: [CustomerAccount]) {
        DispatchQueue.global(qos: .background).async {
            self.privateMOC.performAndWait {
                records.forEach { account in
                    let id = account.accountID ?? ""
                    let existingCDAccount = self.getCDAccount(by: id)
                    if existingCDAccount == nil {
                        self.insert(customerAccount: account)
                    } else {
                        self.update(customerAccount: account)
                    }
                }
                self.synchronize()
            }
        }
    }
    
    func delete(records: [CustomerAccount]) {
        DispatchQueue.global(qos: .background).async {
            self.privateMOC.performAndWait {
                records.forEach { account in
                    if let cdAccount = self.getCDAccount(by: account.accountID ?? "") {
                        self.privateMOC.delete(cdAccount)
                    }
                }
                self.synchronize()
            }
        }
    }
    
    func fetchAll(completion: @escaping (([CustomerAccount]?) -> Void)) {
        DispatchQueue.global(qos: .background).async {
            self.privateMOC.performAndWait {
                let fetchReq = CDAccount.fetchRequest()
                let records = try? self.privateMOC.fetch(fetchReq)
                let accounts = records?.toCustomerAccounts()
                completion(accounts)
            }
        }
    }
    
    typealias T = CustomerAccount
    
}

extension CDAccountEntity {
    private func insert(customerAccount: CustomerAccount) {
        let cdAccount = CDAccount(context: self.privateMOC)
        cdAccount.accountID = customerAccount.accountID
        cdAccount.firstName = customerAccount.firstName
        cdAccount.lastName = customerAccount.lastName
        cdAccount.accountStatus = customerAccount.accountStatus
        cdAccount.email = customerAccount.email
        cdAccount.paymentID = customerAccount.paymentID
        cdAccount.createdDate = Int64(customerAccount.createdDate ?? 0)
        cdAccount.activeDate = Int64(customerAccount.activeDate ?? 0)
        cdAccount.disableDate = Int64(customerAccount.disableDate ?? 0)
        cdAccount.updatedDate = Int64(customerAccount.updatedDate ?? 0)
    }
    private func update(customerAccount: CustomerAccount) {
        
        let exsistingCDAccount = getCDAccount(by: customerAccount.accountID ?? "")
        exsistingCDAccount?.accountID = customerAccount.accountID
        exsistingCDAccount?.firstName = customerAccount.firstName
        exsistingCDAccount?.lastName = customerAccount.lastName
        exsistingCDAccount?.accountStatus = customerAccount.accountStatus
        exsistingCDAccount?.email = customerAccount.email
        exsistingCDAccount?.paymentID = customerAccount.paymentID
        exsistingCDAccount?.createdDate = Int64(customerAccount.createdDate ?? 0)
        exsistingCDAccount?.activeDate = Int64(customerAccount.activeDate ?? 0)
        exsistingCDAccount?.disableDate = Int64(customerAccount.disableDate ?? 0)
        exsistingCDAccount?.updatedDate = Int64(customerAccount.updatedDate ?? 0)
        
    }
    private func getCDAccount(by id: String) -> CDAccount? {
        var cdAccount: CDAccount?
        self.privateMOC.performAndWait {
            let fetchReq = CDAccount.fetchRequest()
            fetchReq.predicate = NSPredicate(format: "accountID == %@", id)
            let records = try? privateMOC.fetch(fetchReq)
            cdAccount = records?.first
        }
        return cdAccount
    }
}
