//
//  CDAccounts+CoreDataClass.swift
//  CoreDataExample
//
//  Created by Sachin Pampannavar on 26/12/22.
//
//

import Foundation
import CoreData

@objc(CDAccount)
public class CDAccount: NSManagedObject {

    enum key: String {
        case accountID
        case accountStatus
        case activeDate
        case createdDate
        case disableDate
        case email
        case firstName
        case lastName
        case paymentID
        case updatedDate
    }
}

// MARK: - Account
struct CustomerAccount: Codable {
    
    let accountID, firstName, lastName, email: String?
       let activeDate, disableDate: Int?
       let accountStatus: String?
       let createdDate, updatedDate: Int?
       let paymentID: String?

       enum CodingKeys: String, CodingKey {
           case accountID = "accountId"
           case firstName, lastName, email, activeDate, disableDate, accountStatus, createdDate, updatedDate
           case paymentID = "paymentId"
       }
}
