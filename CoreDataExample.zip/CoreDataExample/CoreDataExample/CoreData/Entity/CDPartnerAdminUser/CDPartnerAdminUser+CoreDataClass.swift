//
//  CDPartnerAdminUser+CoreDataClass.swift
//  CoreDataExample
//
//  Created by Sachin Pampannavar on 26/12/22.
//
//

import Foundation
import CoreData

@objc(CDPartnerAdminUser)
public class CDPartnerAdminUser: NSManagedObject {

    enum key: String {
        case accountId
        case accountLangauge
        case accountStatus
        case activeDate
        case createdDate
        case disableDate
        case email
        case firstName
        case lastName
        case name
        case paymentId
        case phone
        case role
        case updatedDate
        case orgID
    }
}

// MARK: - PartnerAdminUser
struct PartnerAdminUser: Codable {
    let accountID, firstName, lastName, email, name, paymentId: String?
    let role, accountStatus, accountLanguage, phoneNumber: String?
    let activeDate, disableDate, createdDate, updatedDate: Int?
    var orgID: String?

    enum CodingKeys: String, CodingKey {
        case accountID = "accountId"
        case firstName, lastName, email, role, accountStatus, accountLanguage, phoneNumber, activeDate, disableDate, createdDate, updatedDate, name, paymentId
        case orgID
    }
}
