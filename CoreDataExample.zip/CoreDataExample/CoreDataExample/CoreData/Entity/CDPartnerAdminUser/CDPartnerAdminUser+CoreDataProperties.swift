//
//  CDPartnerAdminUser+CoreDataProperties.swift
//  CoreDataExample
//
//  Created by Sachin Pampannavar on 26/12/22.
//
//

import Foundation
import CoreData


extension CDPartnerAdminUser {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<CDPartnerAdminUser> {
        return NSFetchRequest<CDPartnerAdminUser>(entityName: "CDPartnerAdminUser")
    }

    @NSManaged public var accountId: String?
    @NSManaged public var accountLangauge: String?
    @NSManaged public var accountStatus: String?
    @NSManaged public var activeDate: Int64
    @NSManaged public var createdDate: Int64
    @NSManaged public var disableDate: Int64
    @NSManaged public var email: String?
    @NSManaged public var firstName: String?
    @NSManaged public var lastName: String?
    @NSManaged public var name: String?
    @NSManaged public var paymentId: String?
    @NSManaged public var phone: String?
    @NSManaged public var role: String?
    @NSManaged public var updatedDate: Int64
    @NSManaged public var orgID: String?

}

extension CDPartnerAdminUser : Identifiable {

}

extension CDPartnerAdminUser {
    func toPartnerAdminUser() -> PartnerAdminUser? {
        return PartnerAdminUser(accountID: accountId,
                                firstName: firstName,
                                lastName: lastName,
                                email: email,
                                name: name,
                                paymentId: paymentId,
                                role: role,
                                accountStatus: accountStatus,
                                accountLanguage: accountLangauge,
                                phoneNumber: phone,
                                activeDate: Int(activeDate),
                                disableDate: Int(disableDate),
                                createdDate: Int(createdDate),
                                updatedDate: Int(updatedDate),
                                orgID: orgID)
                                    
    }
}

extension Array where Element: CDPartnerAdminUser {
    func toPartnerAdminUsers() -> [PartnerAdminUser]? {
        var partnerAdminUsers = [PartnerAdminUser]()
        self.forEach { cdPartnerAdminUser in
            if let user = cdPartnerAdminUser.toPartnerAdminUser() {
                partnerAdminUsers.append(user)
            }
        }
        return partnerAdminUsers
    }
}
