//
//  CDPartnerAdminUserEntity.swift
//  CoreDataExample
//
//  Created by Sachin Pampannavar on 26/12/22.
//

import Foundation

class CDPartnerAdminUserEntity: BaseEntity { }

extension CDPartnerAdminUserEntity: CoreDataOperations {
    func insertOrUpdate(records: [PartnerAdminUser]) {
        DispatchQueue.global(qos: .background).async {
            self.privateMOC.performAndWait {
                records.forEach { user in
                    let accountID = user.accountID ?? ""
                    let existingCDPartnerAdminUser = self.getCDPartnerAdminUser(by: accountID)
                    if existingCDPartnerAdminUser == nil {
                        self.insert(user: user)
                    } else {
                        self.update(user: user)
                    }
                }
                self.synchronize()
            }
        }
    }
    
    func delete(records: [PartnerAdminUser]) {
        DispatchQueue.global(qos: .background).async {
            self.privateMOC.performAndWait {
                records.forEach { user in
                    if let cdPartnerAdminUser = self.getCDPartnerAdminUser(by: user.accountID ?? "") {
                        self.privateMOC.delete(cdPartnerAdminUser)
                    }
                }
                self.synchronize()
            }
        }
    }
    
    func fetchAll(completion: @escaping (([PartnerAdminUser]?) -> Void)) {
        DispatchQueue.global(qos: .background).async {
            self.privateMOC.performAndWait {
                let fetchReq = CDPartnerAdminUser.fetchRequest()
                let records = try? self.privateMOC.fetch(fetchReq)
                let partnerAdminUsers = records?.toPartnerAdminUsers()
                completion(partnerAdminUsers)
            }
        }
    }
    
    typealias T = PartnerAdminUser
    
    
}

extension CDPartnerAdminUserEntity {
    private func insert(user: PartnerAdminUser) {
        let cdUser = CDPartnerAdminUser(context: self.privateMOC)
        cdUser.firstName = user.firstName
        cdUser.lastName = user.lastName
        cdUser.name = user.name
        cdUser.email = user.email
        cdUser.role = user.role
        cdUser.phone = user.phoneNumber
        cdUser.accountStatus = user.accountStatus
        cdUser.disableDate = Int64(user.disableDate ?? 0)
        cdUser.accountId = user.accountID
        cdUser.activeDate = Int64(user.activeDate ?? 0)
        cdUser.createdDate = Int64(user.createdDate ?? 0)
        cdUser.updatedDate = Int64(user.updatedDate ?? 0)
        cdUser.orgID = user.orgID
    }
    private func update(user: PartnerAdminUser) {
        let existingCDUser = getCDPartnerAdminUser(by: user.accountID ?? "")
        existingCDUser?.firstName = user.firstName
        existingCDUser?.lastName = user.lastName
        existingCDUser?.name = user.name
        existingCDUser?.email = user.email
        existingCDUser?.role = user.role
        existingCDUser?.phone = user.phoneNumber
        existingCDUser?.accountStatus = user.accountStatus
        existingCDUser?.disableDate = Int64(user.disableDate ?? 0)
        existingCDUser?.accountId = user.accountID
        existingCDUser?.activeDate = Int64(user.activeDate ?? 0)
        existingCDUser?.createdDate = Int64(user.createdDate ?? 0)
        existingCDUser?.updatedDate = Int64(user.updatedDate ?? 0)
        existingCDUser?.orgID = user.orgID
    }
    private func getCDPartnerAdminUser(by id: String) -> CDPartnerAdminUser? {
        var cdPartnerAdminUser: CDPartnerAdminUser?
        self.privateMOC.performAndWait {
            let fetchReq = CDPartnerAdminUser.fetchRequest()
            fetchReq.predicate = NSPredicate(format: "accountID == %@", id)
            let records = try? privateMOC.fetch(fetchReq)
            cdPartnerAdminUser = records?.first
        }
        return cdPartnerAdminUser
    }
}
