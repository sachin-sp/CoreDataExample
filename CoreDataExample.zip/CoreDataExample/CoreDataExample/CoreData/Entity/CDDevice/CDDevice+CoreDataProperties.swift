//
//  CDDevice+CoreDataProperties.swift
//  CoreDataExample
//
//  Created by Sachin Pampannavar on 26/12/22.
//
//

import Foundation
import CoreData


extension CDDevice {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<CDDevice> {
        return NSFetchRequest<CDDevice>(entityName: "CDDevice")
    }

    @NSManaged public var activeDate: Int64
    @NSManaged public var areaId: String?
    @NSManaged public var claimed: Bool
    @NSManaged public var connectionStatus: String?
    @NSManaged public var createdDate: Int64
    @NSManaged public var deviceID: String?
    @NSManaged public var deviceName: String?
    @NSManaged public var deviceStatus: String?
    @NSManaged public var deviceType: String?
    @NSManaged public var disableDate: Int64
    @NSManaged public var ipAddress: String?
    @NSManaged public var locationId: String?
    @NSManaged public var macAddress: String?
    @NSManaged public var modelNumber: String?
    @NSManaged public var orgID: String?
    @NSManaged public var serialNo: String?
    @NSManaged public var updatedDate: Int64
    
    @NSManaged public var properties: CDProperty?

}

extension CDDevice : Identifiable {

}

extension CDDevice {
    func toDevice() -> Device? {
        return Device(deviceID: deviceID,
                      serialNo: serialNo,
                      macAddress: macAddress,
                      orgID: orgID,
                      deviceStatus: deviceStatus,
                      modelNumber: modelNumber,
                      claimed: claimed,
                      ipAddress: ipAddress,
                      deviceType: deviceType,
                      deviceName: deviceName,
                      connectionStatus: connectionStatus,
                      createdDate: Int(createdDate),
                      updatedDate: Int(updatedDate),
                      activeDate: Int(activeDate),
                      disableDate: Int(disableDate),
                      locationId: locationId,
                      areaId: areaId,
                      properties: properties?.toProperties())
    }
}

extension Array where Element: CDDevice {
    func toDevices() -> [Device]? {
        var devices = [Device]()
        self.forEach { cdDevice in
            if let device = cdDevice.toDevice() {
                devices.append(device)
            }
        }
        return devices
    }
}
