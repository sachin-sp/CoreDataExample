//
//  CDDeviceEntity.swift
//  CoreDataExample
//
//  Created by Sachin Pampannavar on 26/12/22.
//

import Foundation

class CDDeviceEntity: BaseEntity { }

extension CDDeviceEntity: CoreDataOperations {
    func insertOrUpdate(records: [Device]) {
        DispatchQueue.global(qos: .background).async {
            self.privateMOC.performAndWait {
                records.forEach { device in
                    let deviceID = device.deviceID ?? ""
                    let existingCDDevice = self.getCDDevice(by: deviceID)
                    if existingCDDevice == nil {
                        self.insert(device: device)
                    } else {
                        self.update(device: device)
                    }
                }
                self.synchronize()
            }
        }
    }
    
    func delete(records: [Device]) {
        DispatchQueue.global(qos: .background).async {
            self.privateMOC.performAndWait {
                records.forEach { device in
                    if let cdDevice = self.getCDDevice(by: device.deviceID ?? "") {
                        self.privateMOC.delete(cdDevice)
                    }
                }
                self.synchronize()
            }
        }
    }
    
    func fetchAll(completion: @escaping (([Device]?) -> Void)) {
        DispatchQueue.global(qos: .background).async {
            self.privateMOC.performAndWait {
                let fetchReq = CDDevice.fetchRequest()
                let records = try? self.privateMOC.fetch(fetchReq)
                let devices = records?.toDevices()
                completion(devices)
            }
        }
    }
    
    typealias T = Device
    
    
}

extension CDDeviceEntity {
    private func insert(device: Device) {
        let newCDDevice = CDDevice(context: self.privateMOC)
        newCDDevice.activeDate = Int64(device.activeDate ?? 0)
        newCDDevice.areaId = device.areaId
        newCDDevice.claimed = device.claimed ?? false
        newCDDevice.connectionStatus = device.connectionStatus
        newCDDevice.createdDate = Int64(device.createdDate ?? 0)
        newCDDevice.deviceID = device.deviceID
        newCDDevice.deviceName = device.deviceName
        newCDDevice.deviceStatus = device.deviceStatus
        newCDDevice.deviceType = device.deviceType
        newCDDevice.disableDate = Int64(device.disableDate ?? 0)
        newCDDevice.ipAddress = device.ipAddress
        newCDDevice.locationId = device.locationId
        newCDDevice.macAddress = device.macAddress
        newCDDevice.modelNumber = device.modelNumber
        newCDDevice.orgID = device.orgID
        newCDDevice.serialNo = device.serialNo
        newCDDevice.updatedDate = Int64(device.updatedDate ?? 0)
        
        let property = device.properties
        insertOrUpdateProperty(property: property, cdDevice: newCDDevice)
    }
    private func update(device: Device) {
        let existingCDDevice = getCDDevice(by: device.deviceID ?? "")
        existingCDDevice?.activeDate = Int64(device.activeDate ?? 0)
        existingCDDevice?.areaId = device.areaId
        existingCDDevice?.claimed = device.claimed ?? false
        existingCDDevice?.connectionStatus = device.connectionStatus
        existingCDDevice?.createdDate = Int64(device.createdDate ?? 0)
        existingCDDevice?.deviceID = device.deviceID
        existingCDDevice?.deviceName = device.deviceName
        existingCDDevice?.deviceStatus = device.deviceStatus
        existingCDDevice?.deviceType = device.deviceType
        existingCDDevice?.disableDate = Int64(device.disableDate ?? 0)
        existingCDDevice?.ipAddress = device.ipAddress
        existingCDDevice?.locationId = device.locationId
        existingCDDevice?.macAddress = device.macAddress
        existingCDDevice?.modelNumber = device.modelNumber
        existingCDDevice?.orgID = device.orgID
        existingCDDevice?.serialNo = device.serialNo
        existingCDDevice?.updatedDate = Int64(device.updatedDate ?? 0)
        
        let property = device.properties
        insertOrUpdateProperty(property: property, cdDevice: existingCDDevice)
    }
    private func getCDDevice(by id: String) -> CDDevice? {
        var cdDevice: CDDevice?
        self.privateMOC.performAndWait {
            let fetchReq = CDDevice.fetchRequest()
            fetchReq.predicate = NSPredicate(format: "deviceID == %@", id)
            let records = try? privateMOC.fetch(fetchReq)
            cdDevice = records?.first
        }
        return cdDevice
    }
}

extension CDDeviceEntity {
    
    private func insertOrUpdateProperty(property: Properties?, cdDevice: CDDevice?) {
        let existingCDProperty = getCDProperty(by: property?.modelID ?? "")
        if existingCDProperty == nil {
            let newCDProperty = CDProperty(context: self.privateMOC)
            newCDProperty.connected = property?.connected
            newCDProperty.modelID = property?.modelID
            newCDProperty.timeZone = property?.timeZone
            cdDevice?.properties = newCDProperty
        } else {
            existingCDProperty?.connected = property?.connected
            existingCDProperty?.modelID = property?.modelID
            existingCDProperty?.timeZone = property?.timeZone
            cdDevice?.properties = existingCDProperty
        }
    }
    
    private func getCDProperty(by id: String) -> CDProperty? {
        var cdProperty: CDProperty?
        self.privateMOC.performAndWait {
            let fetchReq = CDProperty.fetchRequest()
            fetchReq.predicate = NSPredicate(format: "modelID == %@", id)
            let records = try? self.privateMOC.fetch(fetchReq)
            cdProperty = records?.first
        }
        return cdProperty
    }
}
