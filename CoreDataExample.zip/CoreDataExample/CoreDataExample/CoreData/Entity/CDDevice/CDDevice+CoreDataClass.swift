//
//  CDDevice+CoreDataClass.swift
//  CoreDataExample
//
//  Created by Sachin Pampannavar on 26/12/22.
//
//

import Foundation
import CoreData

@objc(CDDevice)
public class CDDevice: NSManagedObject {

    enum key: String {
        case activeDate
        case areaId
        case claimed
        case connectionStatus
        case createdDate
        case deviceID
        case deviceName
        case deviceStatus
        case deviceType
        case disableDate
        case ipAddress
        case locationId
        case macAddress
        case modelNumber
        case orgID
        case serialNo
        case updatedDate
        case properties
    }
}

// MARK: - Device
struct Device: Codable, Hashable {
    var deviceID, serialNo, macAddress, orgID: String?
    var deviceStatus, modelNumber: String?
    var claimed: Bool?
    var ipAddress, deviceType, deviceName, connectionStatus: String?
    var createdDate, updatedDate, activeDate, disableDate: Int?
    var locationId, areaId: String?
    var properties: Properties?

    enum CodingKeys: String, CodingKey {
        case deviceID = "deviceId"
        case serialNo, macAddress
        case orgID = "orgId"
        case deviceStatus, modelNumber, claimed, ipAddress, deviceType, deviceName, createdDate, updatedDate, activeDate, disableDate, properties, connectionStatus
        case locationId, areaId
    }
}
