//
//  BaseEntity.swift
//  CoreDataExample
//
//  Created by Sachin Pampannavar on 24/12/22.
//

import UIKit
import CoreData


class BaseEntity {
    
    let serialQueue = DispatchQueue(label: "CoreDataSerialQueue")
    var managedObjectContext: NSManagedObjectContext!
    let privateMOC = NSManagedObjectContext(concurrencyType: .privateQueueConcurrencyType)
    
    var didUpdateDB: Observable<Bool> = Observable(false)
    
    init(context: NSManagedObjectContext? = nil) {
        if context == nil {
            self.managedObjectContext = self.getContex()
        } else {
            self.managedObjectContext = context
        }
        if let context = self.managedObjectContext {
            // Add Observer
            let notificationCenter = NotificationCenter.default
            notificationCenter.addObserver(self, selector: #selector(managedObjectContextObjectsDidChange), name: Notification.Name.NSManagedObjectContextObjectsDidChange, object: context)
            notificationCenter.addObserver(self, selector: #selector(managedObjectContextWillSave), name: Notification.Name.NSManagedObjectContextWillSave, object: context)
            notificationCenter.addObserver(self, selector: #selector(managedObjectContextDidSave), name: Notification.Name.NSManagedObjectContextDidSave, object: context)
        }
        privateMOC.parent = self.managedObjectContext
    }
    private func getContex() -> NSManagedObjectContext? {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return nil }
        let context = appDelegate.coreDataManager.managedObjectContext
        return context
    }
    @objc func managedObjectContextObjectsDidChange(notification: Notification) {
        print("managedObjectContextObjectsDidChange")
        self.didUpdateDB.value = true
       /*guard let userInfo = notification.userInfo else { return }
        if let inserts = userInfo[NSInsertedObjectsKey] as? Set<NSManagedObject>, inserts.count > 0 {
            print("--- INSERTS ---")
            print(inserts)
            print("+++++++++++++++")
        }
        
        if let updates = userInfo[NSUpdatedObjectsKey] as? Set<NSManagedObject>, updates.count > 0 {
            print("--- UPDATES ---")
            for update in updates {
                print(update.changedValues())
            }
            print("+++++++++++++++")
        }
        
        if let deletes = userInfo[NSDeletedObjectsKey] as? Set<NSManagedObject>, deletes.count > 0 {
            print("--- DELETES ---")
            print(deletes)
            print("+++++++++++++++")
        }*/
    }
    @objc func managedObjectContextWillSave(notification: Notification) {
        //print("managedObjectContextWillSave")
    }
    @objc func managedObjectContextDidSave(notification: Notification) {
        //print("managedObjectContextDidSave")
    }
    
    func synchronize() {
        do {
            try self.privateMOC.save() // We call save on the private context, which moves all of the changes into the main queue context without blocking the main queue.
            self.managedObjectContext.performAndWait {
                do {
                    try self.managedObjectContext.save()
                } catch {
                    print("Could not synchonize data. \(error), \(error.localizedDescription)")
                }
            }
        } catch {
            print("Could not synchonize data. \(error), \(error.localizedDescription)")
        }
    }
    
    deinit {
        let notificationCenter = NotificationCenter.default
        notificationCenter.removeObserver(self, name: Notification.Name.NSManagedObjectContextObjectsDidChange, object: self.managedObjectContext)
        notificationCenter.removeObserver(self, name: Notification.Name.NSManagedObjectContextWillSave, object: self.managedObjectContext)
        notificationCenter.removeObserver(self, name: Notification.Name.NSManagedObjectContextDidSave, object: self.managedObjectContext)
    }
}
