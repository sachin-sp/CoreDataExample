//
//  CDManufacturer+CoreDataProperties.swift
//  CoreDataExample
//
//  Created by Sachin Pampannavar on 26/12/22.
//
//

import Foundation
import CoreData


extension CDManufacturer {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<CDManufacturer> {
        return NSFetchRequest<CDManufacturer>(entityName: "CDManufacturer")
    }

    @NSManaged public var createdDate: Int64
    @NSManaged public var manufacturer: String?
    @NSManaged public var manufacturerSkuId: String?
    @NSManaged public var model: String?
    @NSManaged public var skuStatus: String?
    @NSManaged public var updatedDate: Int64

}

extension CDManufacturer : Identifiable {

}

extension CDManufacturer {
    func toManufacturerData() -> ManufacturerData? {
        return ManufacturerData(manufacturer: manufacturer,
                                manufacturerSkuID: manufacturerSkuId,
                                model: model,
                                skuStatus: skuStatus,
                                createdDate: Int(createdDate),
                                updatedDate: Int(updatedDate))
    }
}

extension Array where Element: CDManufacturer {
    func toManufacturers() -> [ManufacturerData]? {
        var manufacturers = [ManufacturerData]()
        self.forEach { cdManufacturer in
            if let manufacturer = cdManufacturer.toManufacturerData() {
                manufacturers.append(manufacturer)
            }
        }
        return manufacturers
    }
}
