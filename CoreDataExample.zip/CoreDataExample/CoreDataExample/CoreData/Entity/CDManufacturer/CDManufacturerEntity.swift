//
//  CDManufacturerEntity.swift
//  CoreDataExample
//
//  Created by Sachin Pampannavar on 26/12/22.
//

import Foundation

class CDManufacturerEntity: BaseEntity { }

extension CDManufacturerEntity: CoreDataOperations {
    func insertOrUpdate(records: [ManufacturerData]) {
        DispatchQueue.global(qos: .background).async {
            self.privateMOC.performAndWait {
                records.forEach { manufacturer in
                    let model = manufacturer.model ?? ""
                    let existingCDManufacturer = self.getCDManufacturer(by: model)
                    if existingCDManufacturer == nil {
                        self.insert(manufacturer: manufacturer)
                    } else {
                        self.update(manufacturer: manufacturer)
                    }
                }
                self.synchronize()
            }
        }
    }
    
    func delete(records: [ManufacturerData]) {
        DispatchQueue.global(qos: .background).async {
            self.privateMOC.performAndWait {
                records.forEach { manufacturer in
                    if let cdManufacturer = self.getCDManufacturer(by: manufacturer.model ?? "") {
                        self.privateMOC.delete(cdManufacturer)
                    }
                }
                self.synchronize()
            }
        }
    }
    
    func fetchAll(completion: @escaping (([ManufacturerData]?) -> Void)) {
        DispatchQueue.global(qos: .background).async {
            self.privateMOC.performAndWait {
                let fetchReq = CDManufacturer.fetchRequest()
                let records = try? self.privateMOC.fetch(fetchReq)
                let manufacturers = records?.toManufacturers()
                completion(manufacturers)
            }
        }
    }
    
    typealias T = ManufacturerData
    
}

extension CDManufacturerEntity {
    private func insert(manufacturer: ManufacturerData) {
        let cdManufacturer = CDManufacturer(context: self.privateMOC)
        cdManufacturer.manufacturer = manufacturer.manufacturer
        cdManufacturer.manufacturerSkuId = manufacturer.manufacturerSkuID
        cdManufacturer.model = manufacturer.model
        cdManufacturer.skuStatus = manufacturer.skuStatus
        cdManufacturer.createdDate = Int64(manufacturer.createdDate ?? 0)
        cdManufacturer.updatedDate = Int64(manufacturer.updatedDate ?? 0)
    }
    private func update(manufacturer: ManufacturerData) {
        let existingCDManufacturer = getCDManufacturer(by: manufacturer.model ?? "")
        existingCDManufacturer?.manufacturer = manufacturer.manufacturer
        existingCDManufacturer?.manufacturerSkuId = manufacturer.manufacturerSkuID
        existingCDManufacturer?.model = manufacturer.model
        existingCDManufacturer?.skuStatus = manufacturer.skuStatus
        existingCDManufacturer?.createdDate = Int64(manufacturer.createdDate ?? 0)
        existingCDManufacturer?.updatedDate = Int64(manufacturer.updatedDate ?? 0)
    }
    private func getCDManufacturer(by id: String) -> CDManufacturer? {
        var cdManufacturer: CDManufacturer?
        self.privateMOC.performAndWait {
            let fetchReq = CDManufacturer.fetchRequest()
            fetchReq.predicate = NSPredicate(format: "model == %@", id)
            let records = try? privateMOC.fetch(fetchReq)
            cdManufacturer = records?.first
        }
        return cdManufacturer
    }
}
