//
//  CDManufacturer+CoreDataClass.swift
//  CoreDataExample
//
//  Created by Sachin Pampannavar on 26/12/22.
//
//

import Foundation
import CoreData

@objc(CDManufacturer)
public class CDManufacturer: NSManagedObject {

    enum key: String {
        case createdDate
        case manufacturer
        case manufacturerSkuId
        case model
        case skuStatus
        case updatedDate
    }
}

// MARK: - Datum
struct ManufacturerData: Codable {
    let manufacturer, manufacturerSkuID, model, skuStatus: String?
    let createdDate, updatedDate: Int?

    enum CodingKeys: String, CodingKey {
        case manufacturer
        case manufacturerSkuID = "manufacturerSkuId"
        case model, skuStatus, createdDate, updatedDate
    }
}
