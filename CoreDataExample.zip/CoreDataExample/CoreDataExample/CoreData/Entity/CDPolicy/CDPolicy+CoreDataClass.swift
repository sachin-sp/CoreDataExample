//
//  CDPolicy+CoreDataClass.swift
//  CoreDataExample
//
//  Created by Sachin Pampannavar on 26/12/22.
//
//

import Foundation
import CoreData

@objc(CDPolicy)
public class CDPolicy: NSManagedObject {

    enum key: String {
        case policyDes
        case policyID
        case policyName
    }
    
}

// MARK: - Policy
struct Policy: Codable {
    var policyID, policyName, policyDes: String?

    enum CodingKeys: String, CodingKey {
        case policyID = "policyId"
        case policyName, policyDes
    }
}
