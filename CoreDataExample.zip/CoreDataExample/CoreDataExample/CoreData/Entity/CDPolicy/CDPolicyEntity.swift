//
//  CDPolicyEntity.swift
//  CoreDataExample
//
//  Created by Sachin Pampannavar on 26/12/22.
//

import Foundation

class CDPolicyEntity: BaseEntity { }

extension CDPolicyEntity: CoreDataOperations {
    func insertOrUpdate(records: [Policy]) {
        DispatchQueue.global(qos: .background).async {
            self.privateMOC.performAndWait {
                records.forEach { policy in
                    let id = policy.policyID ?? ""
                    let existingCDPolicy = self.getCDPolicy(by: id)
                    if existingCDPolicy == nil {
                        self.insert(policy: policy)
                    } else {
                        self.update(policy: policy)
                    }
                }
                self.synchronize()
            }
        }
    }
    
    func delete(records: [Policy]) {
        DispatchQueue.global(qos: .background).async {
            self.privateMOC.performAndWait {
                records.forEach { policy in
                    if let cdPolicy = self.getCDPolicy(by: policy.policyID ?? "") {
                        self.privateMOC.delete(cdPolicy)
                    }
                }
                self.synchronize()
            }
        }
    }
    
    func fetchAll(completion: @escaping (([Policy]?) -> Void)) {
        DispatchQueue.global(qos: .background).async {
            self.privateMOC.performAndWait {
                let fetchReq = CDPolicy.fetchRequest()
                let records = try? self.privateMOC.fetch(fetchReq)
                let policies = records?.toPolicies()
                completion(policies)
            }
        }
    }
    
    typealias T = Policy
    
}

extension CDPolicyEntity {
    private func insert(policy: Policy) {
        let newPolicy = CDPolicy(context: self.privateMOC)
        newPolicy.policyID = policy.policyID
        newPolicy.policyName = policy.policyName
        newPolicy.policyDes = policy.policyDes
    }
    private func update(policy: Policy) {
        let existingCDPolicy = getCDPolicy(by: policy.policyID ?? "")
        existingCDPolicy?.policyID = policy.policyID
        existingCDPolicy?.policyName = policy.policyName
        existingCDPolicy?.policyDes = policy.policyDes
    }
    
    private func getCDPolicy(by id: String) -> CDPolicy? {
        var cdPolicy: CDPolicy?
        self.privateMOC.performAndWait {
            let fetchReq = CDPolicy.fetchRequest()
            fetchReq.predicate = NSPredicate(format: "policyID == %@", id)
            let records = try? privateMOC.fetch(fetchReq)
            cdPolicy = records?.first
        }
        return cdPolicy
    }
}
