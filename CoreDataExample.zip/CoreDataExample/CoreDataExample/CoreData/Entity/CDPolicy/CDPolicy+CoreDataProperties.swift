//
//  CDPolicie+CoreDataProperties.swift
//  CoreDataExample
//
//  Created by Sachin Pampannavar on 26/12/22.
//
//

import Foundation
import CoreData


extension CDPolicy {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<CDPolicy> {
        return NSFetchRequest<CDPolicy>(entityName: "CDPolicy")
    }

    @NSManaged public var policyDes: String?
    @NSManaged public var policyID: String?
    @NSManaged public var policyName: String?

}

extension CDPolicy : Identifiable {

}

extension CDPolicy {
    func toPolicy() -> Policy? {
        return Policy(policyID: policyID, policyName: policyName, policyDes: policyDes)
    }
}

extension Array where Element: CDPolicy {
    func toPolicies() -> [Policy]? {
        var policies = [Policy]()
        self.forEach { cdPolicy in
            if let policy = cdPolicy.toPolicy() {
                policies.append(policy)
            }
        }
        return policies
    }
}
