//
//  CDOrganisation+CoreDataProperties.swift
//  CoreDataExample
//
//  Created by Sachin Pampannavar on 24/12/22.
//
//

import Foundation
import CoreData


extension CDOrganisation {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<CDOrganisation> {
        return NSFetchRequest<CDOrganisation>(entityName: "CDOrganisation")
    }

    @NSManaged public var activeDate: Int64
    @NSManaged public var addressLine1: String?
    @NSManaged public var addressLine2: String?
    @NSManaged public var city: String?
    @NSManaged public var country: String?
    @NSManaged public var createdDate: Int64
    @NSManaged public var disabledDate: Int64
    @NSManaged public var isAssigned: Bool
    @NSManaged public var orgID: String?
    @NSManaged public var orgLinkedInProfile: String?
    @NSManaged public var orgName: String?
    @NSManaged public var orgStatus: String?
    @NSManaged public var orgType: String?
    @NSManaged public var orgWebsite: String?
    @NSManaged public var partnerLevel: String?
    @NSManaged public var role: String?
    @NSManaged public var selfManaged: Bool
    @NSManaged public var stateName: String?
    @NSManaged public var updatedDate: Int64
    @NSManaged public var zipcode: String?
    @NSManaged public var ein: String?
    @NSManaged public var tin: String?
    
    @NSManaged public var cdPolicies: NSSet?
    @NSManaged public var cdLocations: NSSet?
    @NSManaged public var cdDevices: NSSet?

}


// MARK: Generated accessors for cdPolicies
extension CDOrganisation {

    @objc(addCdPoliciesObject:)
    @NSManaged public func addToCdPolices(_ value: CDPolicy)

    @objc(removeCdPoliciesObject:)
    @NSManaged public func removeFromCdPolices(_ value: CDPolicy)

    @objc(addCdPolicies:)
    @NSManaged public func addToCdPolicies(_ values: NSSet)

    @objc(removeCdPolices:)
    @NSManaged public func removeFromCdPolicies(_ values: NSSet)

}

// MARK: Generated accessors for cdLocations
extension CDOrganisation {

    @objc(addCdLocationsObject:)
    @NSManaged public func addToCdLocations(_ value: CDLocation)

    @objc(removeCdLocationsObject:)
    @NSManaged public func removeFromCdLocations(_ value: CDLocation)

    @objc(addCdLocations:)
    @NSManaged public func addToCdLocations(_ values: NSSet)

    @objc(removeCdLocations:)
    @NSManaged public func removeFromCdLocations(_ values: NSSet)

}

// MARK: Generated accessors for cdDevices
extension CDOrganisation {

    @objc(addCdDevicesObject:)
    @NSManaged public func addToCdDevices(_ value: CDDevice)

    @objc(removeCdDevicesObject:)
    @NSManaged public func removeFromCdDevices(_ value: CDDevice)

    @objc(addCdDevices:)
    @NSManaged public func addToCdDevices(_ values: NSSet)

    @objc(removeCdDevices:)
    @NSManaged public func removeFromCdDevices(_ values: NSSet)

}

extension CDOrganisation : Identifiable {

}

extension CDOrganisation {
    func toCustomerOrganization() -> CustomerOrganization? {
        var locations = [Location]()
        if let cdLocations = self.cdLocations?.allObjects as? [CDLocation] {
            cdLocations.forEach({ cdLocation in
                if let location = cdLocation.toLocation() {
                    locations.append(location)
                }
            })
        }
        var policies = [Policy]()
        if let cdPolicies = self.cdPolicies?.allObjects as? [CDPolicy] {
            cdPolicies.forEach({ cdPolicy in
                if let policy = cdPolicy.toPolicy() {
                    policies.append(policy)
                }
            })
        }
        
        var devices = [Device]()
        if let cdDevices = self.cdDevices?.allObjects as? [CDDevice] {
            cdDevices.forEach({ cdDevice in
                if let device = cdDevice.toDevice() {
                    devices.append(device)
                }
            })
        }
        return CustomerOrganization(orgID: orgID,
                                    orgName: orgName,
                                    orgType: orgType,
                                    addressLine1: addressLine1,
                                    addressLine2: addressLine2,
                                    city: city,
                                    stateName: stateName,
                                    country: country,
                                    zipcode: zipcode,
                                    orgWebsite: orgWebsite,
                                    orgLinkedInProfile: orgLinkedInProfile,
                                    activeDate: Int(activeDate),
                                    disableDate: Int(disabledDate),
                                    orgStatus: orgStatus,
                                    createdDate: Int(createdDate),
                                    updatedDate: Int(updatedDate),
                                    selfManaged: selfManaged,
                                    role: role,
                                    policies: policies,
                                    locations: locations,
                                    devices: devices,
                                    ein: ein,
                                    tin: tin,
                                    partnerLevel: partnerLevel)
        //return Organisation(id: id, name: name, locations: locations)
    }
}

extension Array where Element: CDOrganisation {
    func toOrganisactions() -> [CustomerOrganization]? {
        var organisations = [CustomerOrganization]()
        self.forEach { cdOrganisation in
            if let organisation = cdOrganisation.toCustomerOrganization() {
                organisations.append(organisation)
            }
        }
        return organisations
    }
}

