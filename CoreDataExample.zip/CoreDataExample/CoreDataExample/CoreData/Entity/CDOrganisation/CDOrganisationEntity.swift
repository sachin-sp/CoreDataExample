//
//  CDOrganisationEntity.swift
//  CoreDataExample
//
//  Created by Sachin Pampannavar on 24/12/22.
//

import Foundation
import CoreData


class CDOrganisationEntity: BaseEntity { }

extension CDOrganisationEntity: CoreDataOperations {
    
    typealias T = CustomerOrganization
    
    func insertOrUpdate(records: [CustomerOrganization]) {
        DispatchQueue.global(qos: .background).async {
            self.privateMOC.performAndWait {
                records.forEach { organisation in
                    let id = organisation.orgID ?? ""
                    let existingCDOrganisation = self.getCDOrganisation(by: id)
                    if existingCDOrganisation == nil {
                        self.insert(organisation: organisation)
                    } else {
                        self.update(organisation: organisation)
                    }
                }
                self.synchronize()
            }
        }
    }
    
    func fetchAll(completion: @escaping (([CustomerOrganization]?) -> Void)) {
        DispatchQueue.global(qos: .background).async {
            self.privateMOC.performAndWait {
                let fetchReq = CDOrganisation.fetchRequest()
                let records = try? self.privateMOC.fetch(fetchReq)
                let organisations = records?.toOrganisactions()
                completion(organisations)
            }
        }
    }
    
    func delete(records: [CustomerOrganization]) {
        DispatchQueue.global(qos: .background).async {
            self.privateMOC.performAndWait {
                records.forEach { organisation in
                    if let cdOrganisation = self.getCDOrganisation(by: organisation.orgID ?? "") {
                        self.privateMOC.delete(cdOrganisation)
                    }
                }
                self.synchronize()
            }
        }
    }
}

//MARK: Inser or update Organisation
extension CDOrganisationEntity {
    
    private func insert(organisation: CustomerOrganization) {
        let cdOrganisation = CDOrganisation(context: self.privateMOC)
        cdOrganisation.activeDate = Int64(organisation.activeDate ?? 0)
        cdOrganisation.addressLine1 = organisation.addressLine1
        cdOrganisation.addressLine2 = organisation.addressLine2
        cdOrganisation.city = organisation.city
        cdOrganisation.createdDate = Int64(organisation.createdDate ?? 0)
        cdOrganisation.disabledDate = Int64(organisation.disableDate ?? 0)
        cdOrganisation.isAssigned = organisation.isAssigned ?? false
        cdOrganisation.orgID = organisation.orgID
        cdOrganisation.orgLinkedInProfile = organisation.orgLinkedInProfile
        cdOrganisation.orgName = organisation.orgName
        cdOrganisation.orgStatus = organisation.orgStatus
        cdOrganisation.orgType = organisation.orgType
        cdOrganisation.orgID = organisation.orgID
        cdOrganisation.orgWebsite = organisation.orgWebsite
        cdOrganisation.partnerLevel = organisation.partnerLevel
        cdOrganisation.role = organisation.role
        cdOrganisation.selfManaged = organisation.selfManaged
        cdOrganisation.stateName = organisation.stateName
        cdOrganisation.updatedDate = Int64(organisation.updatedDate ?? 0)
        cdOrganisation.zipcode = organisation.zipcode
        cdOrganisation.ein = organisation.ein
        cdOrganisation.tin = organisation.tin
        
        let policies = organisation.policies ?? []
        policies.forEach { policy in
            self.insertOrUpdatePolicy(policy: policy, cdOrganisation: cdOrganisation)
        }
        
        let locations = organisation.locations ?? []
        locations.forEach { location in
            self.insertOrUpdateLocation(location: location, cdOrganisation: cdOrganisation)
        }
        
        let devices = organisation.devices ?? []
        devices.forEach { device in
            self.insertOrUpdateDevice(device: device, cdOrganisation: cdOrganisation)
        }
    }
    
    private func update(organisation: CustomerOrganization) {
        guard let id = organisation.orgID,
              let existingCDOrganisation = self.getCDOrganisation(by: id) else { return }
        
        existingCDOrganisation.activeDate = Int64(organisation.activeDate ?? 0)
        existingCDOrganisation.addressLine1 = organisation.addressLine1
        existingCDOrganisation.addressLine2 = organisation.addressLine2
        existingCDOrganisation.city = organisation.city
        existingCDOrganisation.createdDate = Int64(organisation.createdDate ?? 0)
        existingCDOrganisation.disabledDate = Int64(organisation.disableDate ?? 0)
        existingCDOrganisation.isAssigned = organisation.isAssigned ?? false
        existingCDOrganisation.orgID = organisation.orgID
        existingCDOrganisation.orgLinkedInProfile = organisation.orgLinkedInProfile
        existingCDOrganisation.orgName = organisation.orgName
        existingCDOrganisation.orgStatus = organisation.orgStatus
        existingCDOrganisation.orgType = organisation.orgType
        existingCDOrganisation.orgID = organisation.orgID
        existingCDOrganisation.orgWebsite = organisation.orgWebsite
        existingCDOrganisation.partnerLevel = organisation.partnerLevel
        existingCDOrganisation.role = organisation.role
        existingCDOrganisation.selfManaged = organisation.selfManaged
        existingCDOrganisation.stateName = organisation.stateName
        existingCDOrganisation.updatedDate = Int64(organisation.updatedDate ?? 0)
        existingCDOrganisation.zipcode = organisation.zipcode
        existingCDOrganisation.ein = organisation.ein
        existingCDOrganisation.tin = organisation.tin
        
        let policies = organisation.policies ?? []
        policies.forEach { policy in
            self.insertOrUpdatePolicy(policy: policy, cdOrganisation: existingCDOrganisation)
        }
        
        let locations = organisation.locations ?? []
        locations.forEach { location in
            self.insertOrUpdateLocation(location: location, cdOrganisation: existingCDOrganisation)
        }
        
        let devices = organisation.devices ?? []
        devices.forEach { device in
            self.insertOrUpdateDevice(device: device, cdOrganisation: existingCDOrganisation)
        }
    }
    
    private func getCDOrganisation(by id: String) -> CDOrganisation? {
        var cdOrganisation: CDOrganisation?
        self.privateMOC.performAndWait {
            let fetchReq = CDOrganisation.fetchRequest()
            fetchReq.predicate = NSPredicate(format: "orgID == %@", id)
            let records = try? self.privateMOC.fetch(fetchReq)
            cdOrganisation = records?.first
        }
        return cdOrganisation
    }
}

//MARK: Inser or update Policy
extension CDOrganisationEntity {
    
    private func insertOrUpdatePolicy(policy: Policy, cdOrganisation: CDOrganisation) {
        let id = policy.policyID ?? ""
        let existingCDPolicy = self.getCDPolicy(by: id)
        if existingCDPolicy == nil {
            let newPolicy = CDPolicy(context: self.privateMOC)
            newPolicy.policyID = policy.policyID
            newPolicy.policyName = policy.policyName
            newPolicy.policyDes = policy.policyDes
            cdOrganisation.addToCdPolices(newPolicy)
        } else {
            existingCDPolicy?.policyID = policy.policyID
            existingCDPolicy?.policyName = policy.policyName
            existingCDPolicy?.policyDes = policy.policyDes
        }
    }
    
    private func getCDPolicy(by id: String) -> CDPolicy? {
        var cdPolicy: CDPolicy?
        self.privateMOC.performAndWait {
            let fetchReq = CDPolicy.fetchRequest()
            fetchReq.predicate = NSPredicate(format: "policyID == %@", id)
            let records = try? self.privateMOC.fetch(fetchReq)
            cdPolicy = records?.first
        }
        return cdPolicy
    }
}

//MARK: Inser or update Location
extension CDOrganisationEntity {
    
    private func insertOrUpdateLocation(location: Location, cdOrganisation: CDOrganisation) {
        let locationID = location.locationID ?? ""
        let existingLocation = getCDLocation(by: locationID)
        if existingLocation == nil {
            let newCDlocation = CDLocation(context: self.privateMOC)
            newCDlocation.orgID = location.orgID
            newCDlocation.locationID = location.locationID
            newCDlocation.locationName = location.locationName
            newCDlocation.addressLine1 = location.addressLine1
            newCDlocation.addressLine2 = location.addressLine2
            newCDlocation.city = location.city
            newCDlocation.state = location.state
            newCDlocation.zipcode = location.zipcode
            newCDlocation.isDefault = location.isDefault
            newCDlocation.country = location.country
            newCDlocation.lat = location.lat ?? 0.0
            newCDlocation.lng = location.lng ?? 0.0
            newCDlocation.createdDate = Int64(location.createdDate)
            newCDlocation.updatedDate = Int64(location.updatedDate ?? 0)
            let areas = location.areas ?? []
            areas.forEach { area in
                insertOrUpdateArea(area: area, cdLocation: newCDlocation)
            }
            cdOrganisation.addToCdLocations(newCDlocation)
        } else {
            existingLocation?.orgID = location.orgID
            existingLocation?.locationID = location.locationID
            existingLocation?.locationName = location.locationName
            existingLocation?.addressLine1 = location.addressLine1
            existingLocation?.addressLine2 = location.addressLine2
            existingLocation?.city = location.city
            existingLocation?.state = location.state
            existingLocation?.zipcode = location.zipcode
            existingLocation?.isDefault = location.isDefault
            existingLocation?.country = location.country
            existingLocation?.lat = location.lat ?? 0.0
            existingLocation?.lng = location.lng ?? 0.0
            existingLocation?.createdDate = Int64(location.createdDate)
            existingLocation?.updatedDate = Int64(location.updatedDate ?? 0)
            let areas = location.areas ?? []
            areas.forEach { area in
                insertOrUpdateArea(area: area, cdLocation: existingLocation)
            }
        }
    }
    
    private func insertOrUpdateArea(area: Area, cdLocation: CDLocation?) {
        let areaID = area.areaID ?? ""
        let existingCDArea = getCDArea(by: areaID)
        if existingCDArea == nil {
            let newCDArea = CDArea(context: self.privateMOC)
            newCDArea.orgID = area.orgID
            newCDArea.locationID = area.locationID
            newCDArea.areaID = area.areaID
            newCDArea.areaName = area.areaName
            newCDArea.isDefault = area.isDefault ?? false
            newCDArea.createdDate = Int64(area.createdDate ?? 0)
            cdLocation?.addToCdAreas(newCDArea)
        } else {
            existingCDArea?.orgID = area.orgID
            existingCDArea?.locationID = area.locationID
            existingCDArea?.areaID = area.areaID
            existingCDArea?.areaName = area.areaName
            existingCDArea?.isDefault = area.isDefault ?? false
            existingCDArea?.createdDate = Int64(area.createdDate ?? 0)
        }
    }
    
    private func getCDLocation(by id: String) -> CDLocation? {
        var cdLocation: CDLocation?
        self.privateMOC.performAndWait {
            let fetchReq = CDLocation.fetchRequest()
            fetchReq.predicate = NSPredicate(format: "locationID == %@", id)
            let records = try? self.privateMOC.fetch(fetchReq)
            cdLocation = records?.first
        }
        return cdLocation
    }
    
    private func getCDArea(by id: String) -> CDArea? {
        var cdArea: CDArea?
        self.privateMOC.performAndWait {
            let fetchReq = CDArea.fetchRequest()
            fetchReq.predicate = NSPredicate(format: "AreaID == %@", id)
            let records = try? self.privateMOC.fetch(fetchReq)
            cdArea = records?.first
        }
        return cdArea
    }
}

//MARK: Inser or update Device
extension CDOrganisationEntity {
    
    private func insertOrUpdateDevice(device: Device, cdOrganisation: CDOrganisation) {
        let id = device.deviceID ?? ""
        let existingCDDevice = self.getCDDevice(by: id)
        if existingCDDevice == nil {
            let newCDDevice = CDDevice(context: self.privateMOC)
            newCDDevice.activeDate = Int64(device.activeDate ?? 0)
            newCDDevice.areaId = device.areaId
            newCDDevice.claimed = device.claimed ?? false
            newCDDevice.connectionStatus = device.connectionStatus
            newCDDevice.createdDate = Int64(device.createdDate ?? 0)
            newCDDevice.deviceID = device.deviceID
            newCDDevice.deviceName = device.deviceName
            newCDDevice.deviceStatus = device.deviceStatus
            newCDDevice.deviceType = device.deviceType
            newCDDevice.disableDate = Int64(device.disableDate ?? 0)
            newCDDevice.ipAddress = device.ipAddress
            newCDDevice.locationId = device.locationId
            newCDDevice.macAddress = device.macAddress
            newCDDevice.modelNumber = device.modelNumber
            newCDDevice.orgID = device.orgID
            newCDDevice.serialNo = device.serialNo
            newCDDevice.updatedDate = Int64(device.updatedDate ?? 0)
            
            let property = device.properties
            insertOrUpdateProperty(property: property, cdDevice: newCDDevice)
        } else {
            existingCDDevice?.activeDate = Int64(device.activeDate ?? 0)
            existingCDDevice?.areaId = device.areaId
            existingCDDevice?.claimed = device.claimed ?? false
            existingCDDevice?.connectionStatus = device.connectionStatus
            existingCDDevice?.createdDate = Int64(device.createdDate ?? 0)
            existingCDDevice?.deviceID = device.deviceID
            existingCDDevice?.deviceName = device.deviceName
            existingCDDevice?.deviceStatus = device.deviceStatus
            existingCDDevice?.deviceType = device.deviceType
            existingCDDevice?.disableDate = Int64(device.disableDate ?? 0)
            existingCDDevice?.ipAddress = device.ipAddress
            existingCDDevice?.locationId = device.locationId
            existingCDDevice?.macAddress = device.macAddress
            existingCDDevice?.modelNumber = device.modelNumber
            existingCDDevice?.orgID = device.orgID
            existingCDDevice?.serialNo = device.serialNo
            existingCDDevice?.updatedDate = Int64(device.updatedDate ?? 0)
            
            let property = device.properties
            insertOrUpdateProperty(property: property, cdDevice: existingCDDevice)
        }
    }
    
    private func insertOrUpdateProperty(property: Properties?, cdDevice: CDDevice?) {
        let existingCDProperty = getCDProperty(by: property?.modelID ?? "")
        if existingCDProperty == nil {
            let newCDProperty = CDProperty(context: self.privateMOC)
            newCDProperty.connected = property?.connected
            newCDProperty.modelID = property?.modelID
            newCDProperty.timeZone = property?.timeZone
            cdDevice?.properties = newCDProperty
        } else {
            existingCDProperty?.connected = property?.connected
            existingCDProperty?.modelID = property?.modelID
            existingCDProperty?.timeZone = property?.timeZone
            cdDevice?.properties = existingCDProperty
        }
    }
    
    private func getCDDevice(by id: String) -> CDDevice? {
        var cdDevice: CDDevice?
        self.privateMOC.performAndWait {
            let fetchReq = CDDevice.fetchRequest()
            fetchReq.predicate = NSPredicate(format: "deviceID == %@", id)
            let records = try? self.privateMOC.fetch(fetchReq)
            cdDevice = records?.first
        }
        return cdDevice
    }
    
    private func getCDProperty(by id: String) -> CDProperty? {
        var cdProperty: CDProperty?
        self.privateMOC.performAndWait {
            let fetchReq = CDProperty.fetchRequest()
            fetchReq.predicate = NSPredicate(format: "modelID == %@", id)
            let records = try? self.privateMOC.fetch(fetchReq)
            cdProperty = records?.first
        }
        return cdProperty
    }
}

extension NSManagedObjectContext {
    func performAndWait<T>(_ block: () throws -> [T]?) throws -> [T]? {
        var result: Result<[T]?, Error>?
        performAndWait {
            result = Result { try block() }
        }
        return try result!.get()
    }

    func performAndWait<T>(_ block: () -> [T]?) -> [T]? {
        var result: [T]?
        performAndWait {
            result = block()
        }
        return result!
    }
}

@available(iOS 15.0.0, *)
extension NSManagedObjectContext {
    func get<E, R>(request: NSFetchRequest<E>) async throws -> [R] where E: NSManagedObject, E: ToSafeObject, R == E.SafeType {
        try await self.perform { [weak self] in
            try self?.fetch(request).compactMap { try $0.safeObject() } ?? []
        }
    }
}

enum SafeMapError: Error {
    case invalidMapping
}

protocol ToSafeObject {
    associatedtype SafeType
    func safeObject() throws -> SafeType
}
