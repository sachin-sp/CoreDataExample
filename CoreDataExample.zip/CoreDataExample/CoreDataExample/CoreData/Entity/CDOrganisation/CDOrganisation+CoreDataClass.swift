//
//  CDOrganisation+CoreDataClass.swift
//  CoreDataExample
//
//  Created by Sachin Pampannavar on 24/12/22.
//
//

import Foundation
import CoreData

@objc(CDOrganisation)
public class CDOrganisation: NSManagedObject {

    enum key: String {
        case activeDate
        case addressLine1
        case addressLine2
        case city
        case country
        case createdDate
        case disabledDate
        case isAssigned
        case orgID
        case orgLinkedInProfile
        case orgName
        case orgSatus
        case orgType
        case orgWebsite
        case partnerLevel
        case role
        case selfManaged
        case stateName
        case updatedDate
        case zipcode
        case cdPolicies
        case cdLocations
        case cdDevices
    }
    
}

// MARK: - Organization
struct CustomerOrganization: Codable {
    
    let orgID, orgName: String?
        let orgType: String?
        let addressLine1: String?
        let addressLine2: String?
        let city, stateName: String?
        let country: String?
        let zipcode: String?
        let orgWebsite, orgLinkedInProfile: String?
        let activeDate, disableDate: Int?
        let orgStatus: String?
        let createdDate, updatedDate: Int?
        let selfManaged: Bool
        let role: String?
        let policies: [Policy]?
        let locations: [Location]?
        let devices: [Device]?
        let ein: String?
        let tin: String?
        let partnerLevel: String?
        var isAssigned: Bool?

        enum CodingKeys: String, CodingKey {
            case orgID = "orgId"
            case orgName, orgType, addressLine1, addressLine2, city, stateName, country, zipcode, orgWebsite, orgLinkedInProfile, activeDate, disableDate, orgStatus, createdDate, updatedDate, selfManaged, role, policies, locations, devices, ein, tin, partnerLevel, isAssigned
        }
    
}

extension CDOrganisation: ToSafeObject {
    func safeObject() throws -> CustomerOrganization {
        guard let org = self.toCustomerOrganization() else {
            throw SafeMapError.invalidMapping
        }
        return org
    }
}
