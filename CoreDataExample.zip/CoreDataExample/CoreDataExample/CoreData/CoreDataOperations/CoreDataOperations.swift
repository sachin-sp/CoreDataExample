//
//  CoreDataOperations.swift
//  CoreDataExample
//
//  Created by Sachin Pampannavar on 24/12/22.
//

import Foundation

protocol CoreDataOperations: AnyObject {
    associatedtype T
    func insertOrUpdate(records: [T])
    func delete(records: [T])
    func fetchAll(completion: @escaping (([T]?) -> Void))
}
