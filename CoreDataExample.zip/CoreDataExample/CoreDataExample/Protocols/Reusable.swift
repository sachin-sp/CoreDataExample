//
//  ReusableProtocol.swift
//  EnDocs
//
//  Created by Sachin Pampannavar on 26/09/22.
//

import Foundation
import UIKit

protocol Reusable: ClassNameProtocol {
  static var reuseIdentifier: String { get }
  static var nib: UINib? { get }
}

extension Reusable {
    static var reuseIdentifier: String { return className}
    static var nib: UINib? {
        guard Bundle.main.path(forResource: className, ofType: "nib") != nil else {
            return nil
        }
        return UINib(nibName: className, bundle: nil)
        
    }
}

extension UITableViewCell: Reusable { }
extension UICollectionViewCell: Reusable { }
