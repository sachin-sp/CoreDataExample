//
//  GlobalFunctions.swift
//  EnDocs
//
//  Created by Sachin Pampannavar on 28/08/22.
//

import Foundation

func getNameOf(_ type: Any) -> String {
    let s = type.self
    return "\(s)"
}

