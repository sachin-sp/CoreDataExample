//
//  UICollectionView+Extension.swift
//  EnDocs
//
//  Created by Sachin Pampannavar on 28/08/22.
//

import UIKit

extension UICollectionView {
    /// Register table cell
    func registerReusableCell<T: UICollectionViewCell>(_: T.Type) {
        if let nib = T.nib {
            self.register(nib, forCellWithReuseIdentifier: T.reuseIdentifier)
        } else {
            self.register(T.self, forCellWithReuseIdentifier: T.reuseIdentifier)
        }
    }

    ///  Dequeue reusable cell for indexpath
    /// - Returns:generic cell
    func dequeueReusableCell<T: UICollectionViewCell>(for indexPath: IndexPath) -> T {
        guard let cell = dequeueReusableCell(withReuseIdentifier: T.reuseIdentifier, for: indexPath) as? T else {
            fatalError("Unable to Dequeue Reusable Table View Cell")
        }
        return cell
    }
    /// Register Header View For Section
    func registerReusableView<T: UICollectionReusableView>(_: T.Type, forSupplementaryViewOfKind elementKind: String) where T: Reusable {
        if let nib = T.nib {
            self.register(nib, forSupplementaryViewOfKind: elementKind, withReuseIdentifier: T.reuseIdentifier)
        } else {
            self.register(T.self, forSupplementaryViewOfKind: elementKind, withReuseIdentifier: T.reuseIdentifier)
        }
    
    }
    
    /// Dequeue Reuable View
    /// - Returns: generic reusable view
    func dequeueReusableView<T: UICollectionReusableView>(forSupplementaryViewOfKind elementKind: String, for indexPath: IndexPath) -> T? where T: Reusable {
        return self.dequeueReusableSupplementaryView(ofKind: elementKind, withReuseIdentifier: T.reuseIdentifier, for: indexPath) as? T? ?? nil
    }
}
