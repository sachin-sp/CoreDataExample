//
//  Collection+Extension.swift
//  EnDocs
//
//  Created by Sachin Pampannavar on 28/08/22.
//


import Foundation

extension Collection where Element: Equatable {
    func allEqual() -> Bool {
        return allSatisfy { first == $0 }
    }
}
