//
//  Encodable+Extension.swift
//  EnDocs
//
//  Created by Sachin Pampannavar on 28/08/22.
//


import Foundation

typealias CustomDictionary = [String: Any]
typealias CustomArray = [[String: Any]]

extension Encodable {
    /// custom Dictionary
    var customDictionary: CustomDictionary {
        return (try? JSONSerialization.jsonObject(with: JSONEncoder().encode(self))) as? [String: Any] ?? [:]
    }
    var customArray: CustomArray {
        return (try? JSONSerialization.jsonObject(with: JSONEncoder().encode(self))) as? [[String: Any]] ?? []
    }
}
