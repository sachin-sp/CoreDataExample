//
//  String+Extension.swift
//  EnDocs
//
//  Created by Sachin Pampannavar on 28/08/22.
//


import Foundation

extension String {
    /// isEmpty after trimming whitespace
    /// - Returns: Yes or No
    public func isEmpty() -> Bool {
        return self.trimming().isEmpty
    }

    /// Trimming White space
    /// - Returns: return new string after trimming characters.
    func trimming() -> String {
        let strText = self.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
        return strText
    }

    /// Remove White Space
    /// - Returns: return new String after replace.
    func removeWhitespace() -> String {
        return self.replace(string: " ", replacement: "")
    }
    /// Replace the string
    /// - Parameters:
    ///   - string: string which need to Change
    ///   - replacement: new String
    /// - Returns: New string with replace
    func replace(string: String, replacement: String) -> String {
        return self.replacingOccurrences(of: string, with: replacement, options: .literal, range: nil)
    }
    
    /// CapitalFirst Letter
    /// - Returns: <#description#>
    func capitalizingFirstLetter() -> String {
        return prefix(1).uppercased() + self.lowercased().dropFirst()
    }
    
    mutating func capitalizeFirstLetter() {
        self = self.capitalizingFirstLetter()
    }
}


