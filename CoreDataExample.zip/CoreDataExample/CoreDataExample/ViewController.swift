//
//  ViewController.swift
//  CoreDataExample
//
//  Created by Sachin Pampannavar on 24/12/22.
//

import UIKit

class ViewController: UIViewController {

    var tv: UITableView!
    var organisations: [CustomerOrganization]?
    
    let cdOrganisationEntity = CDOrganisationEntity()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let b = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addAction))
        self.navigationItem.rightBarButtonItem = b
        
        tv = UITableView(frame: self.view.bounds, style: .grouped)
        tv.dataSource = self
        tv.delegate = self
        self.view.addSubview(tv)
        
        dbOperations()
    }
    
    func dbOperations()  {
        cdOrganisationEntity.didUpdateDB.bind { [weak self] isChanged in
            self?.fetchOrgs()
        }
        fetchOrgs()
    }
    
    func fetchOrgs() {
        self.cdOrganisationEntity.fetchAll { [weak self] organisations in
            self?.organisations = organisations
            DispatchQueue.main.async {
                self?.tv.reloadData()
            }
        }
    }
    
    @objc func addAction() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        loadJson(filename: "OrganisationsData")
    }

    func loadJson(filename fileName: String) {
        if let url = Bundle.main.url(forResource: fileName, withExtension: "json") {
            do {
                let data = try Data(contentsOf: url)

                
                //let decoder = JSONDecoder()
                //let jsonData = try decoder.decode([CustomerOrganization].self, from: data)
                
                guard let json = try JSONSerialization.jsonObject(with: data, options: .fragmentsAllowed) as? [[String: Any]] else { return }
                
                var orgs = [CustomerOrganization]()
                for i in json {
                    let orgId = i["id"] as? String ?? ""
                    let orgName = i["name"] as? String ?? ""
                    let org = CustomerOrganization(orgID: orgId, orgName: orgName, orgType: nil, addressLine1: nil, addressLine2: nil, city: nil, stateName: nil, country: nil, zipcode: nil, orgWebsite: nil, orgLinkedInProfile: nil, activeDate: 0, disableDate: 0, orgStatus: nil, createdDate: 0, updatedDate: 0, selfManaged: true, role: nil, policies: nil, locations: nil, devices: nil, ein: nil, tin: nil, partnerLevel: nil)
                    orgs.append(org)
                }
                
                self.cdOrganisationEntity.delete(records: orgs)
                self.cdOrganisationEntity.insertOrUpdate(records: orgs)
            } catch {
                print("error:\(error)")
            }
        }
    }
    
    deinit {
        print("No =================== retain cycle")
    }
}

extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.organisations?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: "CELL")
        cell.textLabel?.text = self.organisations?[indexPath.row].orgName
        return cell
    }
}

extension ViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

class Observable<T> {
    // MARK: - Properties
    var value: T? {
        didSet {
            for key in listeners.keys {
                listeners[key]?(value)
            }
        }
    }
    // Private
    private var listeners: [String: ((T?) -> Void)] = [:]

    // MARK: - Initializer Methods
    init(_ value: T?) {
        self.value = value
    }

    // MARK: - Public Methods
    /// Bind the closure to get new value in callback.
    /// - Parameter listener: Closure block.
    /// - Returns: Returns an identifier of the block.
    @discardableResult func bind(_ listener: @escaping (T?) -> Void) -> String {
        listener(value)
        let uuid = UUID().uuidString
        listeners[uuid] = listener
        return uuid
    }

    /// Remove closure from listeners.
    /// - Parameter uuid: UUID of the closure.
    func remove(_ uuid: String) {
        listeners.removeValue(forKey: uuid)
    }
}
